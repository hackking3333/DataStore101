var angles = 0;
var sun = document.getElementById("sun");
var moon = document.getElementById("moon");
var sun_buffer;
var moon_bufer;
var cloud_buffer = [];
var cloud_show = [];

function convertImageToBase64(imgUrl, callback) {
    const image = new Image();
    image.crossOrigin='anonymous';
    image.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.height = image.naturalHeight;
        canvas.width = image.naturalWidth;
        ctx.drawImage(image, 0, 0);
        const dataUrl = canvas.toDataURL();
        callback && callback(dataUrl,  image);
    }
    image.src = imgUrl;
}

function GetArrayRemove(array, value) {
    var index = array.indexOf(value);
    if (index !== -1) {
        array.splice(index, 1);
    }
}

for (var i=0; i < 37; i++) {
    const getData = i;
    convertImageToBase64("assets/img/Cloud_"+getData.toString()+".png", (imagedata, clouddata) => {
        cloud_buffer[getData] = [imagedata, clouddata];
        // console.log(clouddata.naturalHeight + ' ' + clouddata.naturalWidth);
    });
};
convertImageToBase64("assets/img/Sun.png", (imagedata) => { sun_buffer = imagedata; });
convertImageToBase64("assets/img/Moon.png", (imagedata) => { moon_bufer = imagedata; });

setInterval(() => {
    if (!sun_buffer) { return };
    if (!moon_bufer) { return };
    angles += 0.002;
    angles %= Math.PI*4
    document.getElementById("DebugAngles").innerText = "Angles: "+(angles).toString();
    // var isDayTime = angles < 0 || angles > Math.PI*2;
    var screenMax = window.screen.height > window.screen.width && window.screen.height || window.screen.width;
    var padding = screenMax/2;
    var scosPixel = Math.cos(angles)*padding;
    var ssinPixel = Math.sin(angles)*padding;
    var mcosPixel = Math.cos(angles+Math.PI)*padding;
    var msinPixel = Math.sin(angles+Math.PI)*padding;
    // document.getElementById("sky_background").style.filter = "grayscale("+Math.max(angles-(Math.PI*2), 0)+"%)";
    //console.log(angles%Math.PI);
    //sun.style.width = isDayTime && "150px" || "75px"
    //sun.style.height = isDayTime && "150px" || "75px"
    sun.style["padding" + (ssinPixel>0 && "Top" || "Bottom")] = Math.abs(ssinPixel).toString()+"px";
    sun.style["padding" + (scosPixel>0 && "Left" || "Right")] = Math.abs(scosPixel).toString()+"px";
    moon.style["padding" + (msinPixel>0 && "Top" || "Bottom")] = Math.abs(msinPixel).toString()+"px";
    moon.style["padding" + (mcosPixel>0 && "Left" || "Right")] = Math.abs(mcosPixel).toString()+"px";
}, 1);

setInterval(() => {
    var randomNumber = Math.floor(Math.random()*36);
    var getCloud = cloud_buffer[randomNumber];
    var cloudObject = document.createElement("div");
    // cloudObject.style.backgroundImage = "url('assets/img/Cloud_" + randomNumber + ".png')";
    cloudObject.style.backgroundImage = "url('assets/img/Cloud_0.png')";
    cloudObject.style.height = getCloud[1].naturalHeight + "px";
    cloudObject.style.width = getCloud[1].naturalWidth + "px";
    document.body.appendChild(cloudObject);
    cloud_show.push(cloudObject);
    setTimeout(() => {
        GetArrayRemove(cloud_show, cloudObject);
        cloudObject.remove();
    }, 4000);
}, 1000);