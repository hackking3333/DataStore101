var angles = 0;
var sun = document.getElementById("sun");
var moon = document.getElementById("moon");
var sun_buffer;
var moon_bufer;
var cloud_buffer = [];
var cloud_show = [];
var currentPositionX = 0;
var pumNPC = [-64, -120, -230, -286, -344, -400, -456, -512, -566, -622, -678, -736, -792, -848];

var bgambient = new Rainbow(); 
bgambient.setNumberRange(1, 10000);
bgambient.setSpectrum('ffd27f', 'black', 'black', 'black', 'black', 'black', 'ffd27f', 'white', 'white', 'white', 'white', 'ffd27f');

function convertImageToBase64(imgUrl, callback) {
    const image = new Image();
    image.crossOrigin='anonymous';
    image.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.height = image.naturalHeight;
        canvas.width = image.naturalWidth;
        ctx.drawImage(image, 0, 0);
        const dataUrl = canvas.toDataURL();
        callback && callback(dataUrl,  image);
    }
    image.src = imgUrl;
}

function GetArrayRemove(array, value) {
    var index = array.indexOf(value);
    if (index !== -1) {
        array.splice(index, 1);
    }
}

for (var i=0; i < 37; i++) {
    const getData = i;
    convertImageToBase64("assets/img/Cloud_"+getData.toString()+".png", (imagedata, clouddata) => {
        cloud_buffer[getData] = [imagedata, clouddata];
        // console.log(clouddata.naturalHeight + ' ' + clouddata.naturalWidth);
    });
};
convertImageToBase64("assets/img/Sun.png", (imagedata) => { sun_buffer = imagedata; });
convertImageToBase64("assets/img/Moon.png", (imagedata) => { moon_bufer = imagedata; });

setInterval(() => {
    if (!sun_buffer) { return };
    if (!moon_bufer) { return };
    currentPositionX += 1;
    angles += 0.001;
    angles %= Math.PI*4
    document.getElementById("DebugAngles").innerText = "Angles: "+(angles).toString();
    // var isDayTime = angles < 0 || angles > Math.PI*2;
    var screenMax = window.innerHeight < window.innerHeight && window.innerHeight || window.innerHeight;
    var padding = screenMax/1.5;
    var timeConsumed = angles/Math.PI;
    var scosPixel = Math.cos(angles)*padding;
    var ssinPixel = Math.sin(angles)*padding;
    var mcosPixel = Math.cos(angles+Math.PI)*padding;
    var msinPixel = Math.sin(angles+Math.PI)*padding;
    var sunmoonSize = Math.max(1-Math.pow(Math.abs(((timeConsumed%1)-0.5)*2), 4), 0.5);
    var sunSize = (sunmoonSize*160).toString()+"px";
    var moonSize = (sunmoonSize*70).toString()+"px";
    var bgambientColor = bgambient.colorAt(Math.floor((timeConsumed%2/2)*10000));
    document.getElementById("bg_ambient").style.backgroundColor = "#"+bgambientColor;
    // console.log(bgambientColor);
    sun.style.width = sunSize;
    sun.style.height = sunSize;
    moon.style.width = moonSize;
    moon.style.height = moonSize;
    // document.getElementById("sky_background").style.filter = "grayscale("+Math.max(angles-(Math.PI*2), 0)+"%)";
    //console.log(angles%Math.PI);
    //sun.style.width = isDayTime && "150px" || "75px"
    //sun.style.height = isDayTime && "150px" || "75px"
    document.getElementById("mu0").style.backgroundPositionX = (currentPositionX/8).toString()+"px";
    document.getElementById("mu1").style.backgroundPositionX = (currentPositionX/12).toString()+"px";
    sun.style["padding" + (ssinPixel>0 && "Top" || "Bottom")] = Math.abs(ssinPixel).toString()+"px";
    sun.style["padding" + (scosPixel>0 && "Left" || "Right")] = Math.abs(scosPixel).toString()+"px";
    moon.style["padding" + (msinPixel>0 && "Top" || "Bottom")] = Math.abs(msinPixel).toString()+"px";
    moon.style["padding" + (mcosPixel>0 && "Left" || "Right")] = Math.abs(mcosPixel).toString()+"px";
    /*
    cloud_show.forEach(element => {
        var timeDiff = (new Date().getTime() - element[1])/element[2];
        var leftPos = (window.innerWidth)-timeDiff;
        element[0].style.left = leftPos.toString()+"px";
    });
    */
}, 1);

setInterval(() => {
    var randomNumber = Math.floor(Math.random()*36);
    var getCloud = cloud_buffer[randomNumber];
    var cloudObject = document.createElement("div");
    // cloudObject.style.backgroundImage = "url('assets/img/Cloud_" + randomNumber + ".png')";
    cloudObject.style.backgroundImage = "url('assets/img/Cloud_" + randomNumber + ".png')";
    cloudObject.style.height = getCloud[1].naturalHeight + "px";
    cloudObject.style.width = getCloud[1].naturalWidth + "px";
    cloudObject.className = "bg_cloud";
    cloudObject.style.top = Math.floor(Math.random()*window.innerHeight/3).toString()+"px";
    cloudObject.style.zIndex = Math.floor(Math.random()*3).toString();
    document.body.appendChild(cloudObject);
    // cloud_show.push([cloudObject, new Date().getTime(), Math.random()*10+10]);
    const oldCPX = currentPositionX;
    const speed = Math.floor(Math.random()*3+3);
    const leftSide = setInterval(() => {
        var timeDiff = (currentPositionX - oldCPX)/speed;
        var leftPos = (window.innerWidth)-timeDiff;
        cloudObject.style.left = leftPos.toString()+"px";
        if (cloudObject.offsetLeft < -cloudObject.offsetWidth) {
            clearInterval(leftSide);
            cloudObject.remove();
        }
    }, 1);
}, 2500);

var intervalSet;

document.getElementById("Pummiphach").addEventListener("mouseenter", () => {
    var currentIdx = 0;
    intervalSet = setInterval(() => {
        const getPixel = pumNPC[currentIdx];
        document.getElementById("char_pum").style.objectPosition = "0 "+getPixel.toString()+"px";
        currentIdx++;
        currentIdx %= pumNPC.length;
    }, 100)
});
document.getElementById("Pummiphach").addEventListener("mouseleave", () => {
    document.getElementById("char_pum").style.objectPosition = "0 -8px";
    clearInterval(intervalSet);
});